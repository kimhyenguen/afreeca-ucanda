# [T?] Week 1 · 문화권 조사 보고서

> **인공지능과 경영 · 11주차 협동학습**
> Global AI Ethics Simulator — Week 1 산출물 템플릿
> © 2026 강송희 교수 · CC BY-NC 4.0

---

## 1. 팀 · 배정 문화권

| 항목 | 내용 |
|---|---|
| 팀명 | T? |
| 배정 문화권 | KOREA / USA / CHINA / EUROPE / LATIN_AM / MIDDLE_E / AFRICA 중 택1 |
| 작성일 | 2026-__-__ |
| 작성자 | (이름, 학번) |

## 2. 근거 자료 (최소 2건 · URL 필수)

| # | 자료명 | 출처 유형 | URL | 인용 요지 |
|---|---|---|---|---|
| 1 | Hofstede Insights: KOREA | 학술 DB | https://... | Long-term Orientation 100 |
| 2 | World Values Survey Wave 7 | 국제 조사 | https://... | 집단주의 지수 상위 |
| 3 | (추가) | | | |

## 3. 프레임워크별 문화 해석

| Framework | 문화적 근거 요약 (2~3줄) | 제안 가중치 |
|---|---|---|
| **emotion**  | 예: 情(정) 문화 강함, 공감 기반 판단 우세 | 0.2 |
| **social**   | 예: 집단 · 공동체 규범 중시 | 0.2 |
| **moral**    | 예: 유교적 규범 유지 | 0.2 |
| **identity** | 예: 체면 · 위계 · 역할 정체성 강함 | 0.4 |
| **합계**     | | **1.00** |

> ⚠️ 합계는 반드시 1.00 이어야 합니다. `python scripts/validate_scenarios.py` 로 자동 검증됩니다.

## 4. 가설 (Value-Check 대상)

> **H1.** 우리 문화권(KOREA) 에이전트는 S1(Trolley) 시나리오에서 옵션 **B(방관)** 를 200 에피소드 부근에서 수렴 선택할 것이다.
>
> **H2.** identity 가중치가 높은 문화권일수록 다양성(diversity) 지표가 낮게 수렴할 것이다.
>
> **H3.** ε-decay 가 진행됨에 따라 초기 100 에피소드 대비 최종 100 에피소드의 entropy 는 0.3 이하로 감소할 것이다.

## 5. AI 사용 로그 (핵심 3건 이상 요약)

> 전체 로그는 `logs/ai_usage_log.md` 를 참조.

| Entry | Non-AI 초안 요약 | AI 응답 요약 | 최종 채택 사유 |
|---|---|---|---|
| #1 | | | |
| #2 | | | |
| #3 | | | |

## 6. GitHub 워크플로 증거

- Fork/Clone 명령 로그: (스크린샷 첨부)
- `dev` 브랜치 첫 커밋 SHA: `xxxxxxx`
- 첫 PR 링크: https://github.com/<org>/<repo>/pull/1

---

### 🔍 자기 점검 체크리스트

- [ ] 근거 URL 2건 이상 인용
- [ ] 가중치 합계 = 1.00
- [ ] 가설 3개 이상 (검증 가능한 문장)
- [ ] GitHub PR 생성 및 리뷰어 배정
- [ ] AI 사용 로그 3-entry 이상
